import os
import sqlite3


def check_api_key(api_key: str):
    db_path = os.path.join("src", "db.sqlite")
    with sqlite3.connect(db_path) as conn:
        cur = conn.cursor()
        cur.execute("select name from users where apikey = ?", [api_key])
        row = cur.fetchone()
        if row:
            return row
    return False
