from fastapi import APIRouter, Depends

from auth import get_user

router = APIRouter()

# Create a singleton variable for the dependency
user_dependency = Depends(get_user)


@router.get("/")
async def get_testroute(user: dict = user_dependency):
    return user
