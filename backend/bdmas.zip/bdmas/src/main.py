from fastapi import Depends, FastAPI

from auth import get_user
from routers import public, secure

app = FastAPI()


@app.get("/")
async def read_root():
    return {
        "message": "Welcome to the FastAPI app!",
        "description": "This app provides public and secure endpoints.",
        "public_endpoints": "Accessible at /api/v1/public",
        "secure_endpoints": "Accessible at /api/v1/secure (requires authentication)",
    }


app.include_router(public.router, prefix="/api/v1/public")
app.include_router(secure.router, prefix="/api/v1/secure", dependencies=[Depends(get_user)])
