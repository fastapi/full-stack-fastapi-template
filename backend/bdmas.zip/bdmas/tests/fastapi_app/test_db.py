import os
import sqlite3
import unittest


class TestCheckApiKey(unittest.TestCase):
    def setUp(self):
        db_path = os.path.join("src", "db.sqlite")
        self.conn = sqlite3.connect(db_path)
        self.cur = self.conn.cursor()

    def tearDown(self):
        # Close the database connection
        self.conn.close()

    def test_invalid_api_key(self):
        self.cur.execute("select name from users")
        result = self.cur.fetchone()
        assert bool(result)


if __name__ == "__main__":
    unittest.main()
