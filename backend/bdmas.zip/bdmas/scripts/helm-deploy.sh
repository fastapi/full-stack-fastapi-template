#!/usr/bin/env sh

# Exit in case of error
set -e

# Define variables
CHART_PACKAGE=$(ls *.tgz | head -n 1)  # Automatically pick the first .tgz file
RELEASE_NAME="sdp"
NAMESPACE="default"
BACKEND_PORT=8000
TIMEOUT=360  # 6 minute timeout

# Check if a chart package exists
if [ -z "$CHART_PACKAGE" ]; then
  echo "Error: No .tgz file found. Please run build.sh first."
  exit 1
fi

# Deploy the Helm chart
echo "Deploying Helm chart from package: $CHART_PACKAGE..."
helm upgrade --install $RELEASE_NAME $CHART_PACKAGE --namespace $NAMESPACE --timeout ${TIMEOUT}s --wait

echo "Deployment completed successfully!"

# Port forwarding section
echo "Starting port forwarding..."

# Get pod names using go-template
echo "🔍 Getting pod names..."
PODS=$(kubectl get pods -o go-template --template '{{range .items}}{{.metadata.name}}{{"\n"}}{{end}}')

# Identify backend, frontend, and adminer pods
BACKEND_POD=""

for pod in $PODS; do
  if echo "$pod" | grep -q "backend"; then
    BACKEND_POD="$pod"
    ADMINER_POD="$pod"
  fi
done

# Report found pods
if [ -z "$BACKEND_POD" ]; then
  echo "⚠️ Could not find backend pod, skipping..."
else
  echo "✅ Backend pod: $BACKEND_POD"
fi

# Start port forwarding for available pods
echo "🔌 Starting port forwarding..."

if [ -n "$BACKEND_POD" ]; then
  kubectl port-forward pod/$BACKEND_POD $BACKEND_PORT:8000 &
  BACKEND_PID=$!
  echo "🌐 Backend API: http://localhost:$BACKEND_PORT"
else
  BACKEND_PID=""
fi

# Cleanup on exit
cleanup() {
  echo "🛑 Stopping port forwarding..."
  # Only kill PIDs that exist
  [ -n "$BACKEND_PID" ] && kill $BACKEND_PID 2>/dev/null || true
  exit 0
}
trap cleanup INT

# Keep running
echo "🎯 Press Ctrl+C to stop"
wait